package hftl.simulator.models;

/**
 * Created by nickcariss on 21.06.16.
 */
public class Link {
}
