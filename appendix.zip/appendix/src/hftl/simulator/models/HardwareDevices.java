package hftl.simulator.models;

/**
 * HardwareDevices holds a list of all hardware devices contained in the DB.
 * Needs to be implemented according to system design.
 */
public class HardwareDevices {
}
